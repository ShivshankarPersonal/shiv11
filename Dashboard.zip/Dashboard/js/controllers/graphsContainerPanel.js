(function () {
    'use strict';
    angular.module("graphsContainerPanel", [])
        .directive("graphsContainerPanel", function ($timeout, dashboardFactory) {
            return {
                restrict: 'E',
                templateUrl: 'templates/graphsContainerPanel.html',
                link: function ($scope, element, attr) {
                    $scope.showOverlay = false;
                    $scope.canvasElement = null;
                    $scope.canvasContext = null;
                    $scope.chartInstance = null;

                    $scope.onBefore5min = function (type, data) {
                        data = data !== undefined ? data : dashboardFactory.graphsData[0]['5min'];
                        type = type !== undefined ? type : 'line';
                        if($scope.canvasContext){
                            $scope.canvasContext.clearRect(0, 0, $scope.canvasElement.width, $scope.canvasElement.height);
                        }
                        if($scope.chartInstance){
                            $scope.chartInstance.destroy();
                        }
                        generateGraph(type, data);
                    };
                    $scope.onBefore15min = function (type, data) {
                        $scope.canvasContext.clearRect(0, 0, $scope.canvasElement.width, $scope.canvasElement.height);
                        $scope.chartInstance.destroy();
                        var data = dashboardFactory.graphsData[1]['15min'];
                        generateGraph(type, data);
                    };
                    $scope.onSettingsBtnClick = function () {
                        $scope.showOverlay = !$scope.showOverlay;
                    };

                    //CANVAS

                    function generateGraph(type, data) {
                        var options = {
                            type: type !== undefined ? type : 'line',
                            data: {
                                labels: ["Persistent", "TCS", "Infosys", "Wipro", "Cognizant", "Accenture", "IBM", "TechM"],
                                datasets: [
                                    {
                                        label: 'Share Value',
                                        data: data,
                                        borderWidth: 1,
                                        fill: 'start',
                                        lineTension: .0001,
                                        backgroundColor: "rgba(75,192,192,0.4)",
                                        borderColor: "rgba(75,192,192,1)",
                                        borderCapStyle: 'butt',
                                        borderDash: [],
                                        borderDashOffset: 0.0,
                                        borderJoinStyle: 'miter',
                                        pointBorderColor: "rgba(75,192,192,1)",
                                        pointBackgroundColor: "#fff",
                                        pointBorderWidth: 1,
                                        pointHoverRadius: 5,
                                        pointHoverBackgroundColor: "rgba(75,192,192,1)",
                                        pointHoverBorderColor: "rgba(220,220,220,1)",
                                        pointHoverBorderWidth: 2,
                                        pointRadius: 5,
                                        pointHitRadius: 10
                                    }
                                ]
                            },
                            options: {
                                scales: {
                                    yAxes: [{
                                        ticks: {
                                            reverse: false
                                        }
                                    }]
                                }
                            }
                        };
                        $scope.canvasElement = document.getElementById('canvasContainer')
                        $scope.canvasContext = $scope.canvasElement.getContext('2d');
                        $scope.chartInstance = new Chart($scope.canvasContext, options);

                        // Chart.defaults.global.animationSteps = 50;
                        // Chart.defaults.global.tooltipYPadding = 16;
                        // Chart.defaults.global.tooltipCornerRadius = 0;
                        // Chart.defaults.global.tooltipTitleFontStyle = "normal";
                        // Chart.defaults.global.tooltipFillColor = "rgba(0,160,0,0.8)";
                        // Chart.defaults.global.animationEasing = "easeOutBounce";
                        // Chart.defaults.global.responsive = true;
                        // Chart.defaults.global.scaleLineColor = "black";
                        // Chart.defaults.global.scaleFontSize = 16;
                    }
                    $timeout(function () {
                        var data = dashboardFactory.graphsData[0]['5min'];
                        $scope.onBefore5min('line', data);
                    },100);

                }
            }
        })
})();
